<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'banco');

/** MySQL database username */
define('DB_USER', 'admin');

/** MySQL database password */
define('DB_PASSWORD', '1234');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'BKWumQvr(dY:/h9WI?Xt-6#ZF7~H^G||>`^L`#:W+`t7-X><2/TTRzp]/-YPBkNw');
define('SECURE_AUTH_KEY',  'MbGmCz!fV/cX(QuPxfHw<[zrvxvk?N^=26}d+q*vx+q5-u;A*J97dl:)3jv>QkQy');
define('LOGGED_IN_KEY',    '[,Ng_PX[+|/~eUoMlii$K]ta&5 EB,8T5%w^;P|=P}/Cx~,aC 4~BV0;Eua{ C|x');
define('NONCE_KEY',        'G3_>XF[bLm^bU+jZ8!]puET_l 03w2qe0#Eu 1BxAaa-M8REpUT^6QbF`Vu)S}NN');
define('AUTH_SALT',        'PVlK!eAuQa|7dEWB6`,F-5RS04@+%pzNsb-xxEtI1A@ji?!PNaB GSH%J *fg1xQ');
define('SECURE_AUTH_SALT', '5/RTMQP,o%iX/YJwx9E0E{tWAQsYj`pK}(QwM3a`(QNG5UxuR6?T}:/dN?J3;&>Z');
define('LOGGED_IN_SALT',   'P@0_JHjxkdCMIX#k{|6m:+J4F>8!qf_^rgV2U&DA5]tD-vMTgb3ZiG6${H;jl/3f');
define('NONCE_SALT',       ':6B<@/X ,WE*qi,s|f+T8s;YyH5Vu,GV{&}~Ky^}_[vPsv+FeHmX}Eu,*pEEvCOg');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
